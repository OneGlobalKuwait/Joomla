<?php
/**
 * @package     VirtueMart.vmpayment
 * @subpackage  ogcheckout
 *
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

defined('_JEXEC') or die('Restricted access');

/**
 * OgcheckoutPaymentCore class to create payment widget,
 * send payment request and receive payment response from payment gateway
 *
 * @package     VirtueMart.vmpayment
 * @subpackage  ogcheckout
 * @since       1.0.0
 */
class OgcheckoutPaymentCore
{
        /**
     * @var allowedCountries
     */
    public static $allowedCountries = array(
        'ALA','ALB','DZA','ASM','AND','AGO','AIA','ATA','ATG','ARG','ARM','ABW','AUS','AUT','AZE','BHS','BHR','BGD',
        'BRB','BLR','BEL','BLZ','BEN','BMU','BTN','BOL','BIH','BWA','BVT','BRA','BRN','BGR','BFA','BDI','KHM','CMR',
        'CAN','CPV','CYM','CAF','TCD','CHL','CHN','CXR','CCK','COL','COM','COG','COD','COK','CRI','CIV','HRV','CYP',
        'CZE','DNK','DJI','DMA','DOM','ECU','EGY','SLV','GNQ','ERI','EST','ETH','FLK','FRO','FJI','FIN','FRA','GUF',
        'PYF','ATF','GAB','GMB','GEO','DEU','GHA','GIB','GRC','GRL','GRD','GLP','GUM','GTM','GGY','HTI','HMD','VAT',
        'GIN','GNB','GUY','HND','HKG','HUN','ISL','IND','IDN','IRL','IMN','ISR','ITA','JAM','JPN','JEY','JOR','KAZ',
        'KEN','KIR','KOR','KWT','LAO','LVA','LBN','LSO','LBR','LIE','LTU','LUX','MAC','MKD','MDG','MWI','MYS','MDV',
        'MLI','MLT','MHL','MTQ','MRT','MUS','MYT','MEX','FSM','MDA','MCO','MNG','MNE','MSR','MAR','MOZ','MMR','NAM',
        'NPL','NLD','ANT','NCL','NZL','NIC','NER','NGA','NIU','NFK','MNP','NOR','OMN','PAK','PLW','PSE','PAN','PNG',
        'PRY','PER','PHL','PCN','POL','PRT','PRI','QAT','REU','ROU','RUS','RWA','SHN','KNA','LCA','MAF','SPM','VCT',
        'WSM','SMR','STP','SAU','SEN','SRB','SYC','SLE','SGP','SVK','SVN','SLB','SOM','ZAF','SGS','ESP','LKA','SUR',
        'SJM','SWZ','SWE','CHE','TWN','TJK','TZA','THA','TLS','TGO','TKL','TON','TTO','TUN','TUR','TKM','TCA','TUV',
        'UGA','UKR','ARE','GBR','USA','UMI','URY','UZB','VUT','VEN','VNM','VGB','VIR','WLF','ESH','YEM','ZMB','ZWE'
    );

    /**
     * @var unallowedCountries
     */
    public static $unallowedCountries = array(
        'AFG','CUB','ERI','IRN','IRQ','JPN','KGZ','LBY','PRK','SDN','SSD','SYR'
    );

    /**
     * plugin method list
     *
     * @var    array
     * @since  1.0.0
     */
    public static $paymentMethods = array(
        "ogcheckout_gir" => array(
            'allowedCountries'  => array('DEU')
        ),
        "ogcheckout_ebt" => array(
            'allowedCountries'  => array('SWE')
        ),
        "ogcheckout_npy" => array(
            'allowedCountries'  => array('AUT')
        ),
        "ogcheckout_pli" => array(
            'allowedCountries'  => array('AUS')
        ),
        "ogcheckout_pwy" => array(
            'allowedCountries'  => array('POL')
        ),
        "ogcheckout_epy" => array(
            'allowedCountries'  => array('BGR')
        ),
    );

    /**
     * Get Sid from Ogcheckout gateway by request parameters
     *
     * @param array $fields
     * @return string
     */
    public static function getSid($fields)
    {
        $fields_string = http_build_query($fields);

        $curl = curl_init("https://ogpaystage.oneglobal.com/OgPay/V1/api/GenToken/Validate");

        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($fields));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

        $result = curl_exec($curl);

 
        if (curl_errno($curl)) {
            throw new Exception("Curl error: ". curl_error($curl));
        }
        curl_close($curl);

        return $result;
    }

    /**
     * parser response
     *
     * @param json $response
     * @return array
     */
    protected static function _parse_response ($response) {


        $matches = array();
        $rlines = explode ("\r\n", $response);

        foreach ($rlines as $line) {
            if (preg_match ('/([^:]+): (.*)/im', $line, $matches)) {
                continue;
            }

            if (preg_match ('/([0-9a-f]{32})/im', $line, $matches)) {
                return $matches;
            }
        }

        return $matches;
    }


    /**
     * Post to Ogcheckout Gateway
     *
     * @param : $url, $postParameters
     * @return : string
     */
    private static function post($url, $postParameters)
    {
        $postFields = http_build_query($postParameters, '', '&');

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLINFO_HEADER_OUT, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-type: application/x-www-form-urlencoded;charset=UTF-8'));
        curl_setopt($curl, CURLOPT_FAILONERROR, 1);
        curl_setopt($curl, CURLOPT_POST, count($postParameters));
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postFields);

        $result = curl_exec($curl);
        if (curl_errno($curl)) {
            return false;
        }
        curl_close($curl);

        return $result;
    }

    /**
     * Get Ogcheckout Payment Url by checkout parameters
     *
     * @param string $sid
     * @return string | boolean
     */
    public static function getOgcheckoutPaymentUrl($sid)
    {
        
            
        $ogcheckoutPaymentUrl = $sid;
        return $ogcheckoutPaymentUrl;
    }

    /**
     * Return true if sid is valid md5 format
     *
     * @param  string $sid
     * @return boolean
     */
    public static function isSidValid($sid = '')
    {
        if (preg_match('/^[a-f0-9]{32}$/', $sid)) {
            return true;
        } else {
            return false;
        }
    }

    
}
