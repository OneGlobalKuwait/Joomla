jQuery().ready(function ($) {
    /************/
    /* handlers */
    /************/
    handleDebitType = function () {
        var debit_type = $('#params_ogcheckout_payment_method').val();

        if (debit_type == 1 ) {

            $('.mt').parents('.control-group').hide(); 
            $('.pc').parents('.control-group').hide();
            $('.ogcheckout-countries').parents('.control-group').hide();
              
            
            $('.container').show();

        } else if (debit_type == 0) {

            $('.mt').parents('.control-group').show(); 
            $('.pc').parents('.control-group').show();
            $('.ogcheckout-countries').parents('.control-group').show();
 $('.container').hide();


        }
    }
    /**********/
    /* Events */
    /**********/
    $('#params_ogcheckout_payment_method').change(function () {
        handleDebitType();

    });


    /*****************/
    /* Initial calls */
    /*****************/
   // handleShopMode();
    handleDebitType();

});