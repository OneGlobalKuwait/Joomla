<?php
/**
 *
 * Realex payment plugin
 *
 * @author Valerie Isaksen
 * @version $Id$
 * @package VirtueMart
 * @subpackage payment
 * Copyright (C) 2004 - 2019 Virtuemart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
 *
 * http://virtuemart.net
 */
defined('JPATH_BASE') or die();

jimport('joomla.form.formfield');
class JFormFieldGetOgcheckout extends JFormField {

	/**
	 * Element name
	 *
	 * @access    protected
	 * @var        string
	 */
	var $type = 'getOgcheckout';

	protected function getInput() { 

	vmJsApi::addJScript('adminogcheckout', '/plugins/vmpayment/ogcheckout/assets/js/admin_ogcheckout.js');
	vmJsApi::css('ogcheckout', '/plugins/vmpayment/ogcheckout/assets/css/');
		 

		$getvalue = $this->value;		 
		$explodeFirst = explode('@@', $getvalue);
		$explodePM = explode('##', $explodeFirst[0]);
		$explodeCC = explode('##', $explodeFirst[1]);
		$explodeCuC = explode('##', $explodeFirst[2]);	 
if(isset($explodePM ))
{



		$html = '<div class="container">'; 
				$html .= '<button style="display:none;" type="button" class="save">Save</button>';
				$html .= '<button type="button" class="addMore btn btn-primary">+Add Payment Channels </button></br>';
					$html .= '<table width="50%" class="ogCheckOutTable">';
						for ($i=0; $i < count($explodePM); $i++) { 
							if($i == 0){
								$html .= '<tr class="makeClone" id="tr_1">';
							} else {
								$count = $i+1;
								$html .= '<tr id="tr_'.$count.'">';
							}
							$html .= '<td><input type="text" name="payment_method[]"  value="'.$explodePM[$i].'" class="paymentMethod"></td>';
							$html .= '<td><input type="text" name="channel_code[]"    value="'.$explodeCC[$i].'"  	class="channelCode"> </td>';
							$html .= '<td><input type="text" name="currency_code[]"   value="'.$explodeCuC[$i].'"  class="currencyCode" ></td>';
							$html .= '<td><button type="button" class="remove btn btn-danger">Remove</button></td>';
							
							$html .= '</tr>';										
						}
					
					$html .= '</table>';
					$html .= '<input type="hidden" value="' . count($explodePM) . '" class="counter" name="counter">';
		$html .= '</div>'; 
		$html .= '<input type="hidden" class="finalValueOfOg" name="' . $this->name . '" value="' . $this->value . '"/>';

		
		return $html;
	}else
	 {
	 	return false;
		
	}
	 }

}

?>

<style type="text/css">
	.makeClone .remove{display: none}
</style>

<script type="text/javascript">

jQuery(document).ready(function() { 

    // Add new element
    jQuery(".addMore").click(function() {
    	let counter = jQuery('.counter').val();
    	jQuery('.counter').val(parseInt(counter)+1);
    	let clonedRow = jQuery('tbody tr.makeClone').clone();
    	clonedRow.removeClass('makeClone');
    	clonedRow.attr('id','tr_'+(parseInt(counter)+1))
    	clonedRow.find('input').val('');
    	jQuery('.ogCheckOutTable tr:last').after(clonedRow);
    	return false;
    });

    // Remove element
    jQuery('.container').on('click', '.remove', function() { 
    	let counter = jQuery('.counter').val();
    	if(counter == 1){
    		alert('Atleast 1 row store');
    		return false;
    	}

    	let getTrId = jQuery(this).closest('tr').prop('id');
    	if(getTrId != 'tr_1'){
    		jQuery("#"+getTrId).remove();    		
    		jQuery('.counter').val(parseInt(counter)-1);
    		jQuery('.save').click();
    	}
    }); 	

 	jQuery('.container').on('keyup', '.paymentMethod, .channelCode, .currencyCode', function() {
    	jQuery('.save').click();
    });  

    // Remove element
    jQuery('.save').on('click', function() {
    	let paymentMethod = [];
    	jQuery(".ogCheckOutTable .paymentMethod").each(function() {		 
		    paymentMethod.push(jQuery(this).val());		   
		});
		let paymentMethodJoin = paymentMethod.join('##');

    	let channelCode = [];
    	jQuery(".ogCheckOutTable .channelCode").each(function() {		    
		    channelCode.push(jQuery(this).val());		   
		});
		let channelCodeJoin = channelCode.join('##');

    	let currencyCode = [];
		jQuery(".ogCheckOutTable .currencyCode").each(function() {		    
		    currencyCode.push(jQuery(this).val());		   
		});
		let currencyCodeJoin = currencyCode.join('##');

		let finalValue = paymentMethodJoin+'@@'+channelCodeJoin+'@@'+currencyCodeJoin;

		jQuery('.finalValueOfOg').val(finalValue);  
    })
    

    
});

</script>