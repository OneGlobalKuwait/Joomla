<?php
/**
 *
 * Realex payment plugin
 *
 * @author Valerie Isaksen
 * @version $Id$
 * @package VirtueMart
 * @subpackage payment
 * Copyright (C) 2004 - 2019 Virtuemart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
 *
 * http://virtuemart.net
 */
defined('JPATH_BASE') or die();

jimport('joomla.form.formfield');
class JFormFieldGetOgcheckout extends JFormField {

	/**
	 * Element name
	 *
	 * @access    protected
	 * @var        string
	 */
	var $type = 'getOgcheckout';

	protected function getInput() { 

	 vmJsApi::addJScript('adminogcheckout', '/plugins/vmpayment/ogcheckout/ogcheckout/assets/js/admin_ogcheckout.js');
	 vmJsApi::css('ogcheckout', '/plugins/vmpayment/ogcheckout/ogcheckout/assets/css/');
		 

		$getvalue = $this->value;		
		$explodeFirst = explode('@@', $getvalue);
		$explodePM = explode('##', $explodeFirst[0]);
		$explodeCC = explode('##', $explodeFirst[1]);
		$explodeCuC = explode('##', $explodeFirst[2]);	 

		$html = '<div class="container">'; 
				$html .= '<button style="display:none;" type="button" class="save">Save</button>';
				$html .= '<button type="button" class="addMore btn btn-primary">+Add Payment Channels </button></br>';
					$html .= '<table  style="padding:15px;" class="ogCheckOutTable">';
					$html .= '<tr>';
					$html .= '<td style="width:20%;font-weight: bold;">Payment Method</td>';
					$html .= '<td style="width:20%; font-weight: bold;">Channel Code</td>';
					$html .= '<td style="width:20%; font-weight: bold;">Currency Code</td>';
					$html .= '</tr>';
						for ($i=0; $i < count($explodePM); $i++) { 
							if($i == 0){
								$html .= '<tr class="makeClone" id="tr_1">';
							} else {
								$count = $i+1;
								$html .= '<tr id="tr_'.$count.'">';
							}
							$html .= '<td><input type="text" name="payment_method[]"  value="'.$explodePM[$i].'" class="paymentMethod" required></td>';
							$html .= '<td><input type="text" name="channel_code[]"    value="'.$explodeCC[$i].'"  	class="channelCode" required> </td>';
							$html .= '<td><input type="text" name="currency_code[]"   value="'.$explodeCuC[$i].'"  class="currencyCode" required></td>';

							$html .= '<td><button type="button" style="background:red;color:#fff;" class="removed">Remove</button></td>';
							
							$html .= '</tr>';										
						}
					
					$html .= '</table>';
					$html .= '<input type="hidden" value="' . count($explodePM) . '" class="counter" name="counter">';
		$html .= '</div>'; 
		$html .= '<input type="hidden" class="finalValueOfOg" name="' . $this->name . '" value="' . $this->value . '"/>';

		
		return $html;
	
	 }

}

?>