<?php
/**
 * @package     VirtueMart.vmpayment
 * @subpackage  ogcheckout
 *
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

defined('_JEXEC') or die('Restricted access');

/**
 * OgcheckoutPaymentCore class to create payment widget,
 * send payment request and receive payment response from payment gateway
 *
 * @package     VirtueMart.vmpayment
 * @subpackage  ogcheckout
 * @since       1.0.0
 */
class OgcheckoutPaymentCore
{
        

    /**
     * Get Sid from Ogcheckout gateway by request parameters
     *
     * @param array $fields
     * @return string
     */
    public static function getSid($fields)
    {
        $fields_string = http_build_query($fields);

        $curl = curl_init("https://ogpaystage.oneglobal.com/OgPay/V1/api/GenToken/Validate");

        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($fields));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

        $result = curl_exec($curl);
 
        if (curl_errno($curl)) {
            throw new Exception("Curl error: ". curl_error($curl));
        }
        curl_close($curl);

        return $result;
    }

    /**
     * parser response
     *
     * @param json $response
     * @return array
     */
    protected static function _parse_response ($response) {


        $matches = array();
        $rlines = explode ("\r\n", $response);

        foreach ($rlines as $line) {
            if (preg_match ('/([^:]+): (.*)/im', $line, $matches)) {
                continue;
            }

            if (preg_match ('/([0-9a-f]{32})/im', $line, $matches)) {
                return $matches;
            }
        }

        return $matches;
    }


    /**
     * Post to Ogcheckout Gateway
     *
     * @param : $url, $postParameters
     * @return : string
     */
    private static function post($url, $postParameters)
    {
        $postFields = http_build_query($postParameters, '', '&');

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLINFO_HEADER_OUT, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-type: application/x-www-form-urlencoded;charset=UTF-8'));
        curl_setopt($curl, CURLOPT_FAILONERROR, 1);
        curl_setopt($curl, CURLOPT_POST, count($postParameters));
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postFields);

        $result = curl_exec($curl);
        if (curl_errno($curl)) {
            return false;
        }
        curl_close($curl);

        return $result;
    }

    /**
     * Get Ogcheckout Payment Url by checkout parameters
     *
     * @param string $sid
     * @return string | boolean
     */
    public static function getOgcheckoutPaymentUrl($sid)
    {
        
            
        $ogcheckoutPaymentUrl = $sid;
        return $ogcheckoutPaymentUrl;
    }

    /**
     * Return true if sid is valid md5 format
     *
     * @param  string $sid
     * @return boolean
     */
    public static function isSidValid($sid = '')
    {
        if (preg_match('/^[a-f0-9]{32}$/', $sid)) {
            return true;
        } else {
            return false;
        }
    }

    
}
