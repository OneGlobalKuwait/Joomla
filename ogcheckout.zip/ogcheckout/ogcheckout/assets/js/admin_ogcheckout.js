jQuery(document).ready(function() { 
    /************/
    /* handlers */
    /************/
    handleDebitType = function () {
        var debit_type = jQuery('#params_ogcheckout_payment_method').val();

        if (debit_type == 1 ) {

            jQuery('.mt').parents('.control-group').hide(); 
            jQuery('.pc').parents('.control-group').hide();
            jQuery('.ogcheckout-countries').parents('.control-group').hide();
            jQuery('.container').show();

        } else if (debit_type == 0) {

            jQuery('.mt').parents('.control-group').show(); 
            jQuery('.pc').parents('.control-group').show();
            jQuery('.ogcheckout-countries').parents('.control-group').show();
            jQuery('.container').hide();


        }
    }
    /**********/
    /* Events */
    /**********/
    jQuery('#params_ogcheckout_payment_method').change(function () {
        handleDebitType();

    });


    // Add new element
    jQuery(".addMore").click(function() {


        let counter = jQuery('.counter').val();
        jQuery('.counter').val(parseInt(counter)+1);
        let clonedRow = jQuery('tbody tr.makeClone').clone();
        clonedRow.removeClass('makeClone');
        clonedRow.attr('id','tr_'+(parseInt(counter)+1))
        clonedRow.find('input').val('');
        jQuery('.ogCheckOutTable tr:last').after(clonedRow);
        return false;
    });

    // Remove element
    jQuery('.container').on('click', '.removed', function() { 
        let counter = jQuery('.counter').val();
        if(counter == 1){
            alert('Atleast 1 row store');
            return false;
        }

        let getTrId = jQuery(this).closest('tr').prop('id');
        if(getTrId != 'tr_1'){
            jQuery("#"+getTrId).remove();           
            jQuery('.counter').val(parseInt(counter)-1);
            jQuery('.save').click();
        }
    });     

    jQuery('.container').on('keyup', '.paymentMethod, .channelCode, .currencyCode', function() {
        jQuery('.save').click();
    });  

    // Remove element
    jQuery('.save').on('click', function() {
        let paymentMethod = [];
        jQuery(".ogCheckOutTable .paymentMethod").each(function() {      
            paymentMethod.push(jQuery(this).val()); 
            console.log(jQuery(this).val()); 
        });

        let paymentMethodJoin = paymentMethod.join('##');

        let channelCode = [];
        jQuery(".ogCheckOutTable .channelCode").each(function() {           
            channelCode.push(jQuery(this).val());  
            console.log(jQuery(this).val());         
        });
        let channelCodeJoin = channelCode.join('##');

        let currencyCode = [];
        jQuery(".ogCheckOutTable .currencyCode").each(function() {          
            currencyCode.push(jQuery(this).val()); 
            console.log(jQuery(this).val());         
        });
        let currencyCodeJoin = currencyCode.join('##');

        let finalValue = paymentMethodJoin+'@@'+channelCodeJoin+'@@'+currencyCodeJoin;

        jQuery('.finalValueOfOg').val(finalValue);  
    })   


    /*****************/
    /* Initial calls */
    /*****************/
   // handleShopMode();
    handleDebitType();





});