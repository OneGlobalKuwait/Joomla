<?php


defined('_JEXEC') or die();



?>
<div id="paymentMethodOptions_<?php echo $viewData['virtuemart_paymentmethod_id']; ?>" class="paymentMethodOptions" >
    <br />
    <span class="vmpayment_cardinfo">
        <?php 
     //  echo vmText::_('VMPAYMENT_PAYPAL_CC_COMPLETE_FORM');
        ?>
        <table border="0" cellspacing="0" cellpadding="2" width="100%">
            <tr valign="top">
                <td nowrap width="10%" align="right">
                    <label for="creditcardtype"><?php echo "Payment Option"; ?></label>
                </td>
                <td>
						<?php
						$explodeFirst = explode('@@', $viewData['plugin']->getogcheckout);
                        $explodePM = explode('##', $explodeFirst[0]);
                        $explodeCC = explode('##', $explodeFirst[1]);
                        $explodeCuC = explode('##', $explodeFirst[2]);  

						?>  

						    	
                    <?php
                   // foreach ($explodePM as $creditCard) {

                        for ($i=0; $i < count($explodePM); $i++) { 
                        $options[] = JHTML::_('select.option', $explodeCC[$i].'-'.$explodeCuC[$i], vmText::_(strtoupper($explodePM[$i])));
                    }
                    $attribs = 'class="cc_type" rel="1"';
                   echo JHTML::_('select.genericlist', $options, 'cc_type_');
                    ?>
                </td>
            </tr>
        </table>
    </span>
</div>
