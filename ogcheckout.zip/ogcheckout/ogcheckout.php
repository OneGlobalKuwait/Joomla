 <?php

/*
* @author Ogcheckout Holdings Ltd.
* @version $Id: OGCHECKOUT.php 7487 2013-12-17 15:03:42Z alatak $
* @package VirtueMart
* @subpackage payment
* @copyright Copyright (c) 2014 - 2019 VirtueMart Team. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.org
*/

defined ('_JEXEC') or die('Restricted access');
use Joomla\CMS\Factory;
if (!class_exists ('vmPSPlugin')) {
	require(VMPATH_PLUGINLIBS .'/vmpsplugin.php');
}

class plgVmpaymentOgcheckout extends vmPSPlugin {

	/**
	 * payment method
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $paymentMethod;

	/**
	 * plugin config
	 *
	 * @var    string
	 * @since  1.0.0
	 */
	protected $pluginConfig;

	    private $_formdata=[];

	/**
	 * Constructor
	 *
	 * @param 	object $subject The object to observe
	 * @param 	array  $config  An array that holds the plugin configuration
	 * @since 	1.0.0
	 */
	function __construct (&$subject, $config) {

		parent::__construct ($subject, $config);

		if (!class_exists('OgcheckoutPaymentCore'))
		{
			$path = VMPATH_ROOT .'/plugins/vmpayment/ogcheckout/ogcheckout/helpers/core.php';
			if(file_exists($path)) require $path;
		}

		// unique filelanguage for all OGCHECKOUT methods


		// unique filelanguage for all SKRILL methods
		$jlang = JFactory::getLanguage ();
		$jlang->load ('plg_vmpayment_ogcheckout', JPATH_ADMINISTRATOR, NULL, TRUE);
		$this->_loggable = TRUE;
		$this->_debug = TRUE;
		$this->tableFields = array_keys ($this->getTableSQLFields ());
		$this->_tablepkey = 'id'; 
		$this->_tableId = 'id'; 

		$varsToPush = $this->getVarsToPush();
		$this->addVarsToPushCore($varsToPush, 1);
		$this->setConfigParameterable ($this->_configTableFieldName, $varsToPush);
	}

	/**
	 * Get the parameters of a plugin
	 * This function extends from vmPSPlugin class in VirtueMart
	 *
	 * @return  array
	 * @since   1.0.3
	 */
	public function getVarsToPush()
	{
		$varsToPush = parent::getVarsToPush();
		$varsToPush['trial1_duration'] = array(0, 'char');
		$varsToPush['hide_login'] = array(0, 'int');
		$varsToPush['logourl'] = array('', 'char');
		return $varsToPush;
	}


		function _storeInternalData ($method, $mb_data, $virtuemart_order_id) {

		// get all know columns of the table
		$db = JFactory::getDBO ();
		$query = 'SHOW COLUMNS FROM `' . $this->_tablename . '` ';
		$db->setQuery ($query);
		$columns = $db->loadColumn (0);

		$post_msg = '';
		foreach ($mb_data as $key => $value) {
			$post_msg .= $key . "=" . $value . "<br />";
			$table_key = 'mb_' . $key;
			if (in_array ($table_key, $columns)) {
				$response_fields[$table_key] = $value;
			}
		}
         
         //echo '<pre>';
        // print_r($response_fields);
        // die;
		$response_fields['payment_name'] = $mb_data['payment_name'];
		$response_fields['payment_method'] = $mb_data['payment_method'];;
		$response_fields['mbresponse_raw'] = $mb_data['trackid'];
		$response_fields['virtuemart_order_id'] = $virtuemart_order_id;
		$response_fields['virtuemart_paymentmethod_id'] = $method->virtuemart_paymentmethod_id;
		$response_fields['mb_status '] = $mb_data['stauts'];
		$this->storePSPluginInternalData ($response_fields, 'virtuemart_order_id', TRUE);
	}

	/**
	 * Plugin create table SQL
	 *
	 * @return  boolean
	 * @since   1.0.0
	 */
	public function getVmPluginCreateTableSQL () {

		return $this->createTableSQL ('Payment Ogcheckout Table');
	}



	/**
	 * Get payment response HTML
	 *
	 * @param $paymentTable object
	 * @param $payment_name string
	 * @return  object
	 * @since   1.0.0
	 */
	function _getPaymentResponseHtml ($paymentTable, $payment_name) {
		vmLanguage::loadJLang('com_virtuemart');

		$html = '<table>' . "\n";
		$html .= $this->getHtmlRow ('COM_VIRTUEMART_PAYMENT_NAME', $payment_name);
		if (!empty($paymentTable)) {
			$html .= $this->getHtmlRow (vmText::_('VMPAYMENT_OGCHECKOUT_ORDER_NUMBER'), $paymentTable->order_number);
		}
		$html .= '</table>' . "\n";

		return $html;
	}

	/**
	 * Get Internal Data
	 *
	 * @param $virtuemart_order_id int
	 * @param $order_number int
	 * @return  object
	 * @since   1.0.0
	 */
	function _getInternalData ($virtuemart_order_id, $order_number = '') {

		$db = JFactory::getDBO ();
		$q = 'SELECT * FROM `' . $this->_tablename . '` WHERE ';
		if ($order_number) {
			$q .= " `order_number` = '" . $order_number . "'";
		} else {
			$q .= ' `virtuemart_order_id` = ' . $virtuemart_order_id;
		}

		$db->setQuery ($q);
		if (!($paymentTable = $db->loadObject ())) {
			// JError::raiseWarning(500, $db->getErrorMsg());
			return '';
		}
		return $paymentTable;
	}

	/**
	 * Get Table SQL Fields
	 *
	 * @return  array
	 * @since   1.0.0
	 */
	function getTableSQLFields () {

		$SQLfields = array('id'                     => 'int(11) UNSIGNED NOT NULL AUTO_INCREMENT',
		                   'virtuemart_order_id'    => 'int(1) UNSIGNED',
		                   'order_number'           => ' char(64)',
		                   'virtuemart_paymentmethod_id'
		                                             => 'mediumint(1) UNSIGNED',
		                   'payment_name'            => 'varchar(5000)',
		                   'payment_method'          => 'varchar(5000)',
		                   'payment_order_total'     => 'decimal(15,5) NOT NULL DEFAULT \'0.00000\'',
		                   'payment_currency'        => 'char(3) ',
		                   'user_session'            => 'varchar(255)',
		                   'mb_status'               => 'tinyint(1)',
		                   'mbresponse_raw'          => 'varchar(512)');

		return $SQLfields;
	}

	/**
	 * Displays payment widget view
	 *
	 * @param   object $cart 	cart
	 * @param   object $order 	order
	 * @return  boolean|null
	 * @since   1.0.0
	 */
	function plgVmConfirmedOrder ($cart, $order) {


		if (!($method = $this->getVmPluginMethod ($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return NULL;
		} // Another method was selected, do nothing

		if (!$this->selectedThisElement ($method->payment_element)) {
			return FALSE;
		}

		$session = JFactory::getSession ();
        $session_node=$this->_type . '__' . $this->_name;
        $session_data = $session->get($session_node);
        
        $input = Factory::getApplication()->input;
        $errors=[];
        $val = $input->get('cc_type_payment2', 'default_value', 'filter');

		$return_context = $session->getId ();
		$this->logInfo ('plgVmConfirmedOrder order number: ' . $order['details']['BT']->order_number, 'message');

		if (!class_exists ('VirtueMartModelOrders')) {
			require(VMPATH_ADMIN .'/models/orders.php');
		}
		if (!class_exists ('VirtueMartModelCurrency')) {
			require(VMPATH_ADMIN .'/models/currency.php');
		}

		$usrBT = $order['details']['BT'];
		$address = ((isset($order['details']['ST'])) ? $order['details']['ST'] : $order['details']['BT']);

		if (!class_exists ('TableVendors')) {
			require(VMPATH_ADMIN .'/tables/vendors.php');
		}
		$this->getPaymentCurrency ($method);

		$totalInPaymentCurrency = vmPSPlugin::getAmountInCurrency($order['details']['BT']->order_total,$method->payment_currency);
		$cartCurrency = CurrencyDisplay::getInstance($cart->pricesCurrency);

		$lang = JFactory::getLanguage ();
		$tag = substr ($lang->get ('tag'), 0, 2);
		$postVariables = $this->getPostParameters($method, $address, $order, $tag, $totalInPaymentCurrency);
		
		if (!$postVariables) {
			return FALSE;
		}

       $val = $input->get('cc_type_', 'default_value', 'filter');
		
		// Prepare data that should be stored in the database
		$dbValues['user_session'] = $return_context;
		$dbValues['order_number'] = $order['details']['BT']->order_number;
		$dbValues['payment_name'] = $this->renderPluginName ($method, $order);
		$dbValues['virtuemart_paymentmethod_id'] = $cart->virtuemart_paymentmethod_id;
		$dbValues['payment_currency'] = $method->payment_currency;
		$dbValues['payment_order_total'] = $totalInPaymentCurrency['value'];
		$this->storePSPluginInternalData ($dbValues);

		try {
			$sid = OgcheckoutPaymentCore::getSid($postVariables);
		} catch (Exeption $e) {
			//vmInfo (vmText::_ ('ERROR_GENERAL_REDIRECT'));
			return FALSE;
		}

		if (!$sid) {
			//vmInfo (vmText::_ ('ERROR_GENERAL_REDIRECT'));
			return FALSE;	
		}

		$response = json_decode($sid,true);

		if($response['errorCode']==0){
		$response['result']['redirectURL']; 

		$application = JFactory::getApplication();
		$application->redirect($response['result']['redirectURL']);

		$cart->_confirmDone = FALSE;
		$cart->_dataValidated = FALSE;
		$cart->setCartIntoSession ();
		vRequest::setVar ('html', $html);			
	}else
	vmInfo (vmText::_ ('ERROR_GENERAL_REDIRECT'));
			return FALSE;

	}

	/**
     * Get Post Parameters
     *
     * @param $method object
     * @param $address object
     * @param $order array
     * @param $tag string
     * @param $totalInPaymentCurrency array
     * @return array
     */
	private function getPostParameters($method, $address, $order, $tag, $totalInPaymentCurrency)
	{

		$q = 'SELECT `currency_code_3` FROM `#__virtuemart_currencies` WHERE `virtuemart_currency_id`="' .
			$method->payment_currency . '" ';

		$db = JFactory::getDBO ();
		$db->setQuery ($q);
		$currency_code_3 = $db->loadResult ();

		$postParameters = array();
		$paymentMethodKey = strtoupper(vRequest::getVar('ogcheckout_paymentmethod', ''));

		$userReference = $this->generateUserRefrenceId($order['details']['BT']->order_number);
	    $ref=$this->generateRefrenceId($order['details']['BT']->order_number); // set up a blank string
	    $timestamp = date("y/m/d H:m:s t");
		$tunnel = '';
		$amount = $order['details']['BT']->order_total;
		$paymentCode ='ogcheckout';
		$sourceCurrency='';

        $postParameters['merchant_name'] = $method->ogcheckout_merchant_name;
		$postParameters['auth_key'] = $method->ogcheckout_auth_key;
		$postParameters['secretkey'] = $method->ogcheckout_secret_key;
		$postParameters['endpoint'] = $method->ogcheckout_end_point_url;
		$postParameters['tunnel'] = $method->ogcheckout_tunnel;
		$postParameters['payment_method_form'] = $method->ogcheckout_payment_method;
		$postParameters['payment_method_name'] = $method->ogcheckout_method;
		$postParameters['payment_method_currency'] = $method->ogcheckout_currency;
		$postParameters['callback'] =  'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&tmpl=component&ordernumber='.$order['details']['BT']->virtuemart_order_id.'&lang='.vRequest::getCmd('lang',''); 

		$timestamp = str_replace("'\'", "", $timestamp);

		       if($postParameters['payment_method_form'] == 0)
       {


       	   $methodnamepayment = $postParameters['payment_method_name'];
           $methodnamecurrency = $postParameters['payment_method_currency'];

				 if($postParameters['payment_method_name']=='all')
				 {

				 	$sourceCurrency='';
                    $doConvert='N';
                    $methodnamecurrency =$currency_code_3;

				 }else
				 {
					 if($currency_code_3 == $postParameters['payment_method_currency'])
		               {
		                  $sourceCurrency='';
		                  $doConvert='N';
		               }else
		               {
		                  $sourceCurrency=$currency_code_3;
		                  $doConvert='Y';
		               }
				 }   

       }

       $input = Factory::getApplication()->input;
       
       $val = $input->get('cc_type_', 'default_value', 'filter');


       if($postParameters['payment_method_form'] == 1)
       {

         $data_val =  (explode("-",$val));
      
       	   $methodnamepayment = $data_val[0];
       	   $methodnamecurrency = $data_val[1];

               if($currency_code_3 == $methodnamecurrency)
               {
                  $sourceCurrency='';
                  $doConvert='N';
               }else
               {
                  $sourceCurrency=$currency_code_3;
                  $doConvert='Y';
               }
   

       }


 		$datatocomputeHash = (float)$amount.$postParameters['auth_key'].$methodnamecurrency.$method->ogcheckout_merchant_name.$methodnamepayment.(int)$ref.$sourceCurrency.$timestamp.$tunnel.(int)$userReference;
		
        $hash = strtoupper(hash_hmac("sha256", $datatocomputeHash,$postParameters['secretkey']));


        		   $data = array(
			  'merchantCode' => $method->ogcheckout_merchant_name,
			  'authKey' => $method->ogcheckout_auth_key,
			  'currency' => $methodnamecurrency,
			  'pc'=> $methodnamepayment,
			  'tunnel'=> $method->ogcheckout_tunnel,
			  'amount'=> (float)$amount,
			  'doConvert'=> $doConvert,
			  'sourceCurrency'=> $sourceCurrency,
			  'description'=> 'test',
			  'referenceID'=> (int)$ref,
			  'timeStamp'=> $timestamp,
			  'language'=> 'en',
			  'callbackURL'=>JURI::root () .$postParameters['callback'],
			  'hash'=> $hash,
			  'userReference'=> (int)$userReference,
			  'billingDetails'=> array(
					'fName'=> $address->first_name,
					'lName'=> $address->last_name,
					'mobile'=> $address->phone_1,
					'pincode'=> $address->zip,
					'state'=> $address->city,
					'address1'=> $address->address_1,
					'address2'=>$address->address_2
			  ),
		);	

        $request = json_encode($data,true);	   
		return $data;
	}

     
       function generateRefrenceId($orderid){

        $digits_needed = 15;
        
        $orderid = time().$orderid;
        
        $length = strlen((int)$orderid);
		
        if($length<$digits_needed){
		
			$required = $digits_needed-$length;
			
			$id='';
			for ($i = 1; $i <= $required; $i++) {
				   $id .= 1;
			}
			
			$refrenceId = $id.$orderid;
		}else{
			$refrenceId = $id.$orderid;
		}
		
        return (int)$refrenceId;
    }

     function generateUserRefrenceId($uref=""){

        $digits_needed = 10;
        $uref = preg_replace("/[^0-9]/", "", $uref);
        $length = strlen($uref);
		
        if($length<$digits_needed){
		
			$required = $digits_needed-$length;
			
			$id=''; 
			for ($i = 1; $i <= $required; $i++) {
				   $id .= 1;
			}
			
			$refrenceId = $id.$uref;
		}else{
			$refrenceId = $id.$uref;
		}
		
        return (int)$refrenceId;
    }
	

	protected function getPluginHtml($plugin, $selectedPlugin, $pluginSalesPrice)
	{
		 $html='';  
		$pluginmethod_id = $this->_idName;
		$pluginName = $this->_psType . '_name';
		if ($selectedPlugin == $plugin->{$pluginmethod_id}) {
			$checked = 'checked="checked"';
		} else {
			$checked = '';
		}
		
		 $explodeFirst = explode('@@', $plugin->getogcheckout);
		 $explodePM = explode('##', $explodeFirst[0]);
		 $explodeCC = explode('##', $explodeFirst[1]);
		 $explodeCuC = explode('##', $explodeFirst[2]);	
 
		$dynUpdate='';
		if( VmConfig::get('oncheckout_ajax',false)) {
			$dynUpdate=' data-dynamic-update="1" ';
		}
 
    $method_id = $plugin->virtuemart_paymentmethod_id;

$logo ='ogcheckout';

 if( $plugin->ogcheckout_payment_method == 0) {

      $html .= '<input type="radio" '.$dynUpdate.' name="virtuemart_paymentmethod_id" id="' . $this->_psType . '_id_' . $method_id. '"   value="' . $method_id. '" ' . $checked . ">\n"
		. '<label for="' . $this->_psType . '_id_' . $method_id. '">' . '<span class="' . $this->_type . '">' .$plugin->$pluginName. "</span></label>\n"
		. '<img src="plugins/vmpayment/ogcheckout/ogcheckout/assets/images/' . $logo
					. '.png" style="margin: 2px 2px 2px 2px; height:25px !important;"/>';
		 

 }else{

 	    $html .= '<input type="radio" '.$dynUpdate.' name="virtuemart_paymentmethod_id" id="' . $this->_psType . '_id_' . $method_id. '"   value="' . $method_id. '" ' . $checked . ">\n"
		. '<label for="' . $this->_psType . '_id_' . $method_id. '">' . '<span class="' . $this->_type . '">' .$plugin->$pluginName. "</span></label>\n"
		. '<img src="plugins/vmpayment/ogcheckout/ogcheckout/assets/images/' . $logo
					. '.png" style="margin: 2px 2px 2px 2px; height:25px !important;"/>';


}
		return $html;
	}

	/**
	 * Check if the payment conditions are fulfilled for this payment method
	 * @param VirtueMartCart $cart
	 * @param int $activeMethod
	 * @param array $cart_prices
	 * @return bool
	 */
	protected function checkConditions($cart, $activeMethod, $cart_prices) {
		return parent::checkConditions($cart, $activeMethod, $cart_prices);
	}

	/**
     * Get Billing Country code
     *
     * @return string
     */
	protected function getBillingCountryCode() {
		$billingAddress = $this->getAddress('BT');
    	return  ShopFunctions::getCountryByID($billingAddress['virtuemart_country_id'], 'country_3_code');
	}

	/**
     * check whether payment method support country
     *
     * @return array
     */
    protected function isPaymentMethodSupportCountry($paymentMethod, $billingCountryCode)
    {
    	$supportPayment = OgcheckoutPaymentCore::getSupportedPaymentsByCountryCode($billingCountryCode);
    	if (!in_array($paymentMethod, $supportPayment)) {
    		return false;
    	}

        return true;
    }

    /**
	 *	return shipping address if $type ST and billing address if $type is BT
	 *
	 * @param 	string $type type
	 * @return  array
	 * @since   1.1.07
	 */
	protected function getAddress($type)
	{
		$cart = VirtueMartCart::getCart();

		if ($type == 'BT')
		{
			return $cart->BT;
		}

		return $cart->ST;
	}

	/**
	 * Set payment method
	 *
	 * @param   string  $paymentMethod paymet method
	 * @return  void
	 * @since   1.0.0
	 */
	public function setPaymentMethod($paymentMethod)
	{
		$this->paymentMethod = $paymentMethod;
	}

	/**
	 * Set plugin config
	 *
	 * @param   string  $pluginConfig plugin config
	 * @return  void
	 * @since   1.0.0
	 */
	public function setPluginConfig($pluginConfig)
	{
		$this->pluginConfig = $pluginConfig;
	}

	/**
	 * Get plugin config
	 *
	 * @param   string  $key key
	 * @return  string
	 * @since   1.0.0
	 */
	protected function getPluginConfig($key)
	{
		return $this->pluginConfig->$key;
	}

	/**
	 * process Payment Response Received
	 *
	 * @param   string $html html
	 * @return  boolean|null|string
	 * @since   1.0.0
	 */
	function plgVmOnPaymentResponseReceived (&$html) {

	
		if (!class_exists ('VirtueMartCart')) {
			require(VMPATH_SITE . DS . 'helpers' . DS . 'cart.php');
		}
		if (!class_exists ('shopFunctionsF')) {
			require(VMPATH_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
		}
		if (!class_exists ('VirtueMartModelOrders')) {
			require(VMPATH_ADMIN . DS . 'models' . DS . 'orders.php');
		}

		$statusUrlResponse = vRequest::getRequest();

        $payments = $this->getDatasByOrderId($statusUrlResponse['ordernumber']);

		//$order_number = vRequest::getString ('on', 0);
		if (!($method = $this->getVmPluginMethod ($payments[0]->virtuemart_paymentmethod_id))) {
			return NULL;
		} // Another method was selected, do nothing

		if (!$this->selectedThisElement ($method->payment_element)) {
			return NULL;
		}

		if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($payments[0]->order_number))) {
			return NULL;
		}

		if (!($paymentTable = $this->getDataByOrderId ($virtuemart_order_id))) {
			// JError::raiseWarning(500, $db->getErrorMsg());
			return '';
		}
				// Load the payments
		if (!($payments = $this->getDatasByOrderId($virtuemart_order_id)))
		{
			return null;
		}

        $virtuemart_order_id = $statusUrlResponse['ordernumber'];

		if (!isset($statusUrlResponse['ordernumber'])) {
			return;
		}	

		if (!($paymentTable = $this->getDataByOrderId ($statusUrlResponse['ordernumber']))) {
					return '';
				$this->logInfo ('plgVmOnPaymentNotification return new_status:' . $order['order_status'], 'message');
		}
        
        $mb_data = vRequest::getPost();


        vmLanguage::loadJLang('com_virtuemart');
		$orderModel = VmModel::getModel('orders');
		$order = $orderModel->getOrder($virtuemart_order_id);
		//$order = array();



		$order['customer_notified'] = 1;
			$order['order_status'] = 'Completed';
			$order['comments'] = $statusUrlResponse['lang'];

		$order['customer_notified'] = 1;

		$trackid =explode("?trackid=",$statusUrlResponse['lang']);
        $trackids =$trackid[1];

        $mb_data['payment_name'] = $method->payment_element;
        $mb_data['payment_method'] =$payments[0]->virtuemart_paymentmethod_id;
        $mb_data['trackid'] =$trackids; 
        $mb_data['stauts'] =$statusUrlResponse['result']; 
     

          $this->_storeInternalData ($method, $mb_data, $virtuemart_order_id);

    //  echo $method->status_success; die;
		if ($statusUrlResponse['result']== 'CAPTURED') {

			$order['order_status'] = $method->status_success;
			$order['comments'] = vmText::sprintf ('VMPAYMENT_OGCHECKOUT_PAYMENT_STATUS_TRACKID',$trackids);
		}else
		{
			 
			$order['order_status'] =$method->status_canceled;
			$order['comments'] = vmText::sprintf ('VMPAYMENT_OGCHECKOUT_PAYMENT_STATUS_TRACKID', $trackids);
		}

        $payment = $payments[0];
		$this->setPluginConfig($method);
		$this->setPaymentMethod($payment->payment_method);
        $payment_name = $this->renderPluginName($method);

        $orderModel->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);

		$html = $this->_getPaymentResponseHtml ($paymentTable, 'ogcheckout');

		$link=	JRoute::_("index.php?option=com_virtuemart&view=orders&layout=details&order_number=".$order['details']['BT']->order_number."&order_pass=".$order['details']['BT']->order_pass, false) ;

		$html .='<br />
		<a class="vm-button-correct" href="'.$link.'">'.vmText::_('COM_VIRTUEMART_ORDER_VIEW_ORDER').'</a>';

		$cart = VirtueMartCart::getCart ();
		$cart->emptyCart ();
		return TRUE;
		
	}


	function plgVmOnStoreInstallPaymentPluginTable ($jplugin_id) {

		return $this->onStoreInstallPluginTable ($jplugin_id);
	}

	/**
	 * This event is fired after the payment method has been selected. It can be used to store
	 * additional payment info in the cart.
	 *
	 * @author Max Milbers
	 * @author Valérie isaksen
	 *
	 * @param VirtueMartCart $cart: the actual cart
	 * @return null if the payment was not selected, true if the data is valid, error message if the data is not valid
	 *
	 */
	public function plgVmOnSelectCheckPayment (VirtueMartCart $cart,  &$msg)
	{

		if(! $this->selectedThisByMethodId($cart->virtuemart_paymentmethod_id)) {
		          return null; // Another method was selected, do nothing
		       }

		       if(! ($this->_currentMethod = $this->getVmPluginMethod($cart->virtuemart_paymentmethod_id))) {
		          return false;
		       }

		      if(! $this->selectedThisByMethodId($cart->virtuemart_paymentmethod_id)) {
		          return null; // Another method was selected, do nothing
		       }
		       return true;
	}


	public function plgVmDisplayListFEPayment (VirtueMartCart $cart, $selected = 0, &$htmlIn) {
		if ($this->getPluginMethods($cart->vendorId) === 0) {
			if (empty($this->_name)) {
				$app = JFactory::getApplication();
				$app->enqueueMessage(vmText::_('COM_VIRTUEMART_CART_NO_' . strtoupper($this->_psType)));
				return false;
			} else {
				return false;
			}
		}
		$method_name = $this->_psType . '_name';
		$idN = 'virtuemart_'.$this->_psType.'method_id';
		$session = JFactory::getSession ();
		$session_node=$this->_type . '__' . $this->_name;
		$session_data = $session->get($session_node);

           foreach ($this->methods as $this->_currentMethod) {
			if ($this->checkConditions($cart, $this->_currentMethod, $cart->cartPrices)) {
				$html = '';
				$cartPrices=$cart->cartPrices;
				if (isset($this->_currentMethod->cost_method)) {
					$cost_method=$this->_currentMethod->cost_method;
				} else {
					$cost_method=true;
				}
				$key=$method_name . '_html';
				$methodSalesPrice = $this->setCartPrices($cart, $cartPrices, $this->_currentMethod, $cost_method);

				$this->_currentMethod->payment_currency = $this->getPaymentCurrency($this->_currentMethod);
				$this->_currentMethod->$method_name = $this->renderPluginName($this->_currentMethod);

			     if ($selected == $this->_currentMethod->virtuemart_paymentmethod_id) {
                    $checked='checked="checked"';
                } else {
                    $checked='';
                }
				
            if( $this->_currentMethod->ogcheckout_payment_method == 0) 
            {
               $html .= $this->getPluginHtml($this->_currentMethod, $selected, $methodSalesPrice);
            }else
            {
				$html .= $this->getPluginHtml($this->_currentMethod, $selected, $methodSalesPrice);

						
						$html .=$this->renderByLayout('display_payment', [
                         // passed to template as $viewData[]:
                         'plugin' => $this->_currentMethod
                        ,'checked' => $checked
                        ,'payment_cost' => $methodSalesPrice
                        ,'formdata' => $session_data
                    ]);

              }
				$htmlIn[$this->_psType][$this->_currentMethod->$idN] =$html;
			}
		}

		return true;
	}


	public function plgVmonSelectedCalculatePricePayment (VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name) {

		return $this->onSelectedCalculatePrice ($cart, $cart_prices, $cart_prices_name);
	}

	/**
	 * plgVmOnCheckAutomaticSelectedPayment
	 * Checks how many plugins are available. If only one, the user will not have the choice. Enter edit_xxx page
	 * The plugin must check first if it is the correct type
	 *
	 * @author Valerie Isaksen
	 * @param VirtueMartCart cart: the cart object
	 * @return null if no plugin was found, 0 if more then one plugin was found,  virtuemart_xxx_id if only one plugin is found
	 *
	 */
	function plgVmOnCheckAutomaticSelectedPayment (VirtueMartCart $cart, array $cart_prices = array(), &$paymentCounter) {

		return parent::onCheckAutomaticSelected ($cart, $cart_prices, $paymentCounter);
	}

	/**
	 * This method is fired when showing the order details in the frontend.
	 * It displays the method-specific data.
	 *
	 * @param integer $order_id The order ID
	 * @return mixed Null for methods that aren't active, text (HTML) otherwise
	 * @author Max Milbers
	 * @author Valerie Isaksen
	 */
	public function plgVmOnShowOrderFEPayment ($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name) {

		$this->onShowOrderFE ($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
	}

	
	function plgVmonShowOrderPrintPayment ($order_number, $method_id) {

		return $this->onShowOrderPrint ($order_number, $method_id);
	}

	/**
	 * Save updated order data to the method specific table
	 *
	 * @param   array 	$order 			order
	 * @param   string 	$oldOrderStatus old order status
	 * @return  boolean|null
	 * @since   1.0.0
	 */
	public function plgVmOnUpdateOrderPayment(&$order, $oldOrderStatus) {

		if (!($method = $this->getVmPluginMethod($order->virtuemart_paymentmethod_id)))
		{
			// Another method was selected, do nothing
			return null;
		}

		if (!$this->selectedThisElement($method->payment_element))
		{
			return null;
		}

		// Load the payments
		if (!($payments = $this->getDatasByOrderId($order->virtuemart_order_id)))
		{
			return null;
		}
		
 return true;
	}

	/**
	 * Remove the old order status
	 *
	 * @param   int $orderId	order number
	 * @param   string $historyStatus history status
	 * @return  void
	 * @since   1.0.0
	 */
	protected function updateDeleteOldOrderStatus($orderId, $historyStatus)
	{
		$db = JFactory::getDBO();
		$query = "DELETE from `#__virtuemart_order_histories`";
		$query .= " WHERE virtuemart_order_id = '" . $orderId . "' and order_status_code = '". $historyStatus ."'";
		$this->logInfo ('updateDeleteOldOrderStatus query:' . $query, 'message');
		$db->setQuery($query);
		$db->execute();
	}
	
	
	 
	function plgVmDeclarePluginParamsPaymentVM3( &$data) {
		return $this->declarePluginParams('payment', $data);
	}

	function plgVmSetOnTablePluginParamsPayment ($name, $id, &$table) {

		return $this->setOnTablePluginParams ($name, $id, $table);
	}

	

} 